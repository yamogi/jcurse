local f = CreateFrame("FRAME","DSBMainFrame", UIParent)
local configframe = CreateFrame("frame", "DSBConfigFrame")
local xpos = 0
local ypos = 0
local scale = 1
local leftanchor = "CENTER"
local debuffframes = {}
local current = "NIX"
local tooltipspell = {"","","","","",""}
local waagerecht = 1
local showbuffs = 1
local showdebuffs = 1
local showhaste = 1
local testobject = "target"
local initdone = false

local tankdebuffs = {"Weakened Blows", "Curse of Enfeeblement"}
local spelldebuffs = {"Curse of the Elements", "Aura of the Elements", "Fire Breath", "Lightning Breath", "Master Poisoner"}
local physicaldebuffs = {"Physical Vulnerability"}
local armordebuffs = {"Weakened Armor"}

local staminabuffs = {"Commanding Shout", "Dark Intent", "Power Word: Fortitude", "Qiraji Fortitude"}
local statsbuffs = {"Blessing of Kings", "Embrace of the Shale Spider", "Legacy of the Emperor", "Mark of the Wild"}
local masterybuffs = {"Blessing of Might", "Grace of Air", "Roar of Courage", "Spirit Beast Blessing"}
local critbuffs = {"Arcane Brilliance", "Still Water", "Fearless Roar", "Furious Howl", "Terrifying Roar", "Leader of the Pack", "Legacy of the White Tiger", "Dalaran Brilliance"}

local spellhastebuffs = {"Moonkin Aura", "Mind Quickening", "Elemental Oath"}
local meleehastebuffs = {"Unholy Aura", "Cackling Howl", "Serpent's Swiftness", "Swiftblade's Cunning", "Unleashed Rage"}

local RaidWarningMessage = ""


f:SetScript("OnEvent", function(self, event, ...)
    self[event](self, ...)
end)

local function updateFrames()
  for i = 1,6 do
    debuffframes[i]:SetSize(22*scale, 22*scale)
    debuffframes[i]:SetBackdropColor(1, 1, 1, 1)
    debuffframes[i]:SetBackdropBorderColor(0, 0, 0, 1)
    
    --Tooltips
    debuffframes[i]:SetScript("OnEnter", function(self)
      ShowToolTip(i)
    end)
    debuffframes[i]:SetScript("OnLeave", function(self)
      GameTooltip:Hide()
    end)
	debuffframes[i]:SetScript("OnMouseDown", function(self, button)
	  if button == "RightButton" and RaidWarningMessage ~= "" then 
	     SendChatMessage(RaidWarningMessage ,"RAID") 
	  elseif button == "LeftButton" and RaidWarningMessage ~= "" then 
	     print(RaidWarningMessage)
	  end --if
	  
    end)
	
    if i == 1 then
      debuffframes[i]:SetPoint(leftanchor, UIParent, leftanchor, xpos, ypos)
      debuffframes[i]:SetMovable(true)
      debuffframes[i]:EnableMouse(true)
      debuffframes[i]:RegisterForDrag("LeftButton")
      debuffframes[i]:SetScript("OnDragStart", function(self)
        if IsAltKeyDown() then
          self:StartMoving()
        end
      end)
      debuffframes[i]:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        anch,_, _, x, y = self:GetPoint(1)
        xpos = x
        DuneSimpleBuffsDB.xpos = x
        xpos = y
        DuneSimpleBuffsDB.ypos = y
        leftanchor = anch
        DuneSimpleBuffsDB.leftanchor = anch

      end)
      

    else
      if waagerecht == 0 then
         debuffframes[i]:SetPoint("RIGHT", 0, 22*scale + 1)
      else
         debuffframes[i]:SetPoint("RIGHT", 22*scale + 1, 0)
      end
    end

    debuffframes[i]:Show()

  end
end


function CountBuffs(i)
  if i == 1 then names = staminabuffs
  elseif i == 2 then names = statsbuffs
  elseif i == 3 then names = masterybuffs
  else names = critbuffs
  end
	
	members = GetNumGroupMembers();
	if members > 24 then checkcount = 25
	elseif members > 9 then checkcount = 10
	else checkcount = members
	end --if
	Result = 0
	
	if UnitExists("raid1") then
	 grouptype = "raid"
	 counttillX = checkcount
	else
	 grouptype = "party"
	 counttillX = checkcount - 1
	end --if
	
	for i = 1, counttillX do
    AddToResult = 0
    for x = 1, table.getn(names) do
      unitID = grouptype .. i
      if UnitName("player") == UnitName(unitID) then break end
      if UnitExists(unitID) == nil then
        AddToResult = 1
        break
      elseif UnitIsDead(unitID) then
        AddToResult = 1
        break
      elseif not UnitIsConnected(unitID) then
        AddToResult = 1
        break
      elseif UnitExists(unitID) and UnitIsConnected(unitID) and UnitBuff(unitID, names[x]) then 
        AddToResult = 1
        break
      end --if
    end --for
    Result = Result + AddToResult
	end --for
  AddToResult = 0
  for x = 1, table.getn(names) do
    if UnitIsDead("player") then
      AddToResult = 1
      break
    elseif UnitBuff("player", names[x]) then 
      AddToResult = 1
      break
    end --if
  end --for
  Result = Result + AddToResult
  if checkcount > 0 then
    if (checkcount - Result) < 1 then RaidWarningMessage = ""  
	  elseif i == 1 then 	RaidWarningMessage = "+10% Stamina on " .. Result .. " of " .. checkcount
	  elseif i == 2 then 	RaidWarningMessage = "+5% Strength, Agility, Intellect on " .. Result .. " of " .. checkcount
	  elseif i == 3 then 	RaidWarningMessage = "+3000 Mastery Rating on " .. Result .. " of " .. checkcount
	  elseif i == 4 then  RaidWarningMessage = "+5% Critical Strike Chance on " .. Result .. " of " .. checkcount
	  end
	  return Result .. " / " .. checkcount 
  else
	RaidWarningMessage = ""
	return "" end
end


function ShowToolTip(i)
  if (current == "NIX")  or (i > 4 and showhaste ~= 1) then
	RaidWarningMessage = ""
    return 0 
  end --if
  GameTooltip_SetDefaultAnchor(GameTooltip, UIParent)

  if current == "BUFF" then
    if tooltipspell[i] ~= "" and UnitBuff(testobject, tooltipspell[i]) then
      name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId  = UnitBuff(testobject, tooltipspell[i]) 
      GameTooltip:SetUnitBuff(testobject, tooltipspell[i])
	  if unitCaster ~= nil then GameTooltip:AddLine("\n" .. UnitName(unitCaster),0,1,0) end --if
    end --if
	  GameTooltip:AddLine(CountBuffs(i))
  else
    if tooltipspell[i] ~= "" and UnitDebuff(testobject, tooltipspell[i]) then
      name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId  = UnitDebuff(testobject, tooltipspell[i]) 
      GameTooltip:SetUnitDebuff(testobject, tooltipspell[i])
      GameTooltip:AddLine("\n" .. UnitName(unitCaster),0,1,0)
    end --if
  end
  
  GameTooltip:Show()
end


local function initFrames()
  for i = 1,6 do
    debuffframes[i] = CreateFrame("Frame", "DSBFrame"..i, i == 1 and UIParent or debuffframes[i-1])
    debuffframes[i]:SetBackdrop({bgFile=[[Interface\ChatFrame\ChatFrameBackground]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=4,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
  end
  updateFrames()
end

local function destroyFrames()
  for i = 1,6 do
    debuffframes[i]:Hide()
    debuffframes[i] = nil
  end
  debuffframes = {}
end


local function HideFrame()
  for i = 1,6 do
    debuffframes[i]:SetBackdropColor(1, 1, 1, 0)
    debuffframes[i]:SetBackdropBorderColor(0, 1, 1, 0)
    end --for
  current = "NIX"
end

local function BuffCheck(i, names)
  if not UnitExists(testobject) then return 0.1 end --if
  for nameCount = 1, table.getn(names) do
    if UnitBuff(testobject, names[nameCount]) then tooltipspell[i]=names[nameCount];  return 1 end --if
  end 
  return 0.1
end

local function DebuffCheck(i, names)
  if not UnitExists(testobject) then return 0.1 end --if
  for nameCount = 1, table.getn(names) do
    if UnitDebuff(testobject, names[nameCount]) then tooltipspell[i]=names[nameCount];  return 1 end --if
  end 
  return 0.1
end

local function DebuffStackCheck(i, x, names)
  if not UnitExists(testobject) then return 0.1 end --if
  for nameCount = 1, table.getn(names) do
    if UnitDebuff(testobject, names[nameCount]) then 
      name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId  = UnitDebuff(testobject, names[nameCount]) 
      if count == x then 
        tooltipspell[i]=names[nameCount]
        return 1 end --if
    end;
  end
  return 0.1
end

local function RefreshBackdrops()
  if current == "BUFF" then
    debuffframes[1]:SetBackdrop({bgFile=[[Interface\Icons\spell_holy_wordfortitude]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=14*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    debuffframes[2]:SetBackdrop({bgFile=[[Interface\Icons\spell_nature_regeneration]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=14*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    debuffframes[3]:SetBackdrop({bgFile=[[Interface\Icons\spell_holy_greaterblessingofkings]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=15*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    debuffframes[4]:SetBackdrop({bgFile=[[Interface\Icons\spell_holy_magicalsentry]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=15*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    debuffframes[1]:SetBackdropBorderColor(0, 1, 0, 1)
    debuffframes[2]:SetBackdropBorderColor(0, 1, 0, 1)
    debuffframes[3]:SetBackdropBorderColor(0, 1, 0, 1)
    debuffframes[4]:SetBackdropBorderColor(0, 1, 0, 1)
	if showhaste == 1 then
		debuffframes[5]:SetBackdrop({bgFile=[[Interface\Icons\Spell_shadow_spectralsight]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=15*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
		debuffframes[6]:SetBackdrop({bgFile=[[Interface\Icons\Inv_helmet_08]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=15*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
		debuffframes[5]:SetBackdropBorderColor(0, 0, 1, 1)
		debuffframes[6]:SetBackdropBorderColor(0, 0, 1, 1)
	end --if
  elseif current == "DEBUFF" then 
    debuffframes[1]:SetBackdrop({bgFile=[[Interface\Icons\inv_relics_totemofrage]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=14*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    debuffframes[2]:SetBackdrop({bgFile=[[Interface\Icons\warlock_curse_shadow]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=14*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    debuffframes[3]:SetBackdrop({bgFile=[[Interface\Icons\ability_deathknight_brittlebones]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=15*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    debuffframes[4]:SetBackdrop({bgFile=[[Interface\Icons\ability_warrior_sunder]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=15*scale,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
	  debuffframes[1]:SetBackdropBorderColor(1, 0, 0, 1)
    debuffframes[2]:SetBackdropBorderColor(1, 0, 0, 1)
    debuffframes[3]:SetBackdropBorderColor(1, 0, 0, 1)
    debuffframes[4]:SetBackdropBorderColor(1, 0, 0, 1)
    debuffframes[5]:SetBackdropBorderColor(1, 0, 0, 0)
    debuffframes[6]:SetBackdropBorderColor(1, 0, 0, 0)
  else
    for i = 1,6 do
      debuffframes[i]:SetBackdropColor(1, 1, 1, 1)
      debuffframes[i]:SetBackdropBorderColor(0, 0, 0, 1)
      debuffframes[i]:SetBackdrop({bgFile=[[Interface\ChatFrame\ChatFrameBackground]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=4,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
    end --for
  end --if
end


local function updateBuffs()
  if not (current == "BUFF") then
    current = "BUFF"
    RefreshBackdrops()
  end --if
  
  debuffframes[1]:SetBackdropColor(1, 1, 1, BuffCheck(1, staminabuffs))
  debuffframes[2]:SetBackdropColor(1, 1, 1, BuffCheck(2, statsbuffs))
  debuffframes[3]:SetBackdropColor(1, 1, 1, BuffCheck(3, masterybuffs))
  debuffframes[4]:SetBackdropColor(1, 1, 1, BuffCheck(4, critbuffs))
  if showhaste == 1 then
	debuffframes[5]:SetBackdropColor(1, 1, 1, BuffCheck(5, spellhastebuffs))
	debuffframes[6]:SetBackdropColor(1, 1, 1, BuffCheck(6, meleehastebuffs))
  end --if

end

local function updateDebuffs()
  if not (current == "DEBUFF") then
    current = "DEBUFF"
    RefreshBackdrops()
  end --if
  
  debuffframes[1]:SetBackdropColor(1, 1, 1, DebuffCheck(1, tankdebuffs))
  debuffframes[2]:SetBackdropColor(1, 1, 1, DebuffCheck(2, spelldebuffs))
  debuffframes[3]:SetBackdropColor(1, 1, 1, DebuffCheck(3, physicaldebuffs))
  debuffframes[4]:SetBackdropColor(1, 1, 1, DebuffStackCheck(4, 3, armordebuffs))
  debuffframes[5]:SetBackdropColor(1, 1, 1, 0)
  debuffframes[6]:SetBackdropColor(1, 1, 1, 0)
end



------------
-- EVENTS --
------------

function f:UNIT_AURA(UnitID)
  if UnitID == "target" then 
    if UnitExists(testobject) and UnitCanAttack("player", testobject) then 
       if showdebuffs == 1 then updateDebuffs() end
    elseif UnitExists(testobject) and not UnitCanAttack("player", testobject) then 
       if showbuffs == 1 then updateBuffs() end
    else HideFrame()
    end--if
  end --if UnitID
end



function f:PLAYER_FOCUS_CHANGED()
  if testobject == "focus" then
    if UnitExists(testobject) and UnitCanAttack("player", testobject) and showdebuffs == 1 then updateDebuffs()
    elseif UnitExists(testobject) and not UnitCanAttack("player", testobject) and showbuffs == 1 then updateBuffs()
    else HideFrame()
    end --if
  end --if
end

function f:PLAYER_TARGET_CHANGED()
  if testobject == "target" then
    if UnitExists(testobject) and UnitCanAttack("player", testobject) and showdebuffs == 1 then updateDebuffs()
    elseif UnitExists(testobject) and not UnitCanAttack("player", testobject) and showbuffs == 1 then updateBuffs()
    else HideFrame()
    end --if
  end --if
end;

function f:VARIABLES_LOADED()
  if not initdone==true then
    ADDON_LOAD() 
    local initdone=true
  end
end

function ADDON_LOAD()
  --if addon ~= "DuneSimpleBuffs" then return end
  local defaults = {
    xpos = 0,
    ypos = 0,
    scale = 1,
    current = "NIX",
    leftanchor = "CENTER",
    showbuffs = 1,
    showdebuffs = 1,
    testobject = "target",
    waagerecht = 1
  } 
  DuneSimpleBuffsDB = DuneSimpleBuffsDB or {}
    
  for k,v in pairs(defaults) do
    if DuneSimpleBuffsDB[k] == nil then DuneSimpleBuffsDB[k] = v end --if
  end --for

  SLASH_DSB1, SLASH_DSB2 = "/dsb", "/dunesimplebuffs"
  SlashCmdList.DSB = function(txt)
    local cmd, msg = txt:match("^(%S*)%s*(.-)$");
    cmd = string.lower(cmd)
    msg = string.lower(msg)
    if cmd == "reset" then
      xpos = 0
      ypos = 0
      scale = 1
      leftanchor = "CENTER"
      current = "NIX"
      waagerecht = 1
      showbuffs = 1
      showdebuffs = 1
	    showhaste = 1
      testobject = "target"
      DuneSimpleBuffsDB.xpos = 0
      DuneSimpleBuffsDB.ypos = 0
      DuneSimpleBuffsDB.scale = 1
      DuneSimpleBuffsDB.leftanchor = "CENTER"
      DuneSimpleBuffsDB.waagerecht = 1
      DuneSimpleBuffsDB.showbuffs = 1
      DuneSimpleBuffsDB.showdebuffs = 1
      DuneSimpleBuffsDB.showhaste = 1
      DuneSimpleBuffsDB.testobject = "target"
      destroyFrames()
      initFrames()

      print("Frame reset to the center, you can now move it to the desired position.")
	elseif cmd == "say"  then
		SendChatMessage(RaidWarningMessage , "INSTANCE_CHAT")
    elseif cmd == "object" then
      if msg == "target" then 
        testobject = "target"
        DuneSimpleBuffsDB.testobject = "target"
      elseif msg == "player" then 
        testobject = "player"
        DuneSimpleBuffsDB.testobject = "player"
      elseif msg == "focus" then 
        testobject = "focus"
        DuneSimpleBuffsDB.testobject = "focus"
      elseif msg == "boss1" then 
        testobject = "boss1"
        DuneSimpleBuffsDB.testobject = "boss2"
      elseif msg == "boss2" then 
        testobject = "boss2"
        DuneSimpleBuffsDB.testobject = "boss3"
      elseif msg == "boss3" then 
        testobject = "boss3"
        DuneSimpleBuffsDB.testobject = "boss3"
      elseif msg == "boss4" then 
        testobject = "boss4"
        DuneSimpleBuffsDB.testobject = "boss4"
      elseif msg == "boss5" then 
        testobject = "boss5"
        DuneSimpleBuffsDB.testobject = "boss5"
      end
    else
      print("|cff3399FF/dsb|r usage:")
      print("|cff3399FF/dsb reset|r Resets the addon back to default settings. Use if you can't see the frame and/or dragged it out of the screen.")
      print("|cff33FF99To move the boxes:|r Alt+Left mouse button on the leftmost box to drag it.")
      print("|cff33FF99Current Check-Object:|r " .. testobject)
    end

  end

  xpos =        DuneSimpleBuffsDB.xpos
  ypos =        DuneSimpleBuffsDB.ypos
  scale =       DuneSimpleBuffsDB.scale
  leftanchor =  DuneSimpleBuffsDB.leftanchor
  waagerecht =  DuneSimpleBuffsDB.waagerecht
  if not (waagerecht == 1 or waagerecht == 0) then waagerecht = 1 end
  
  showbuffs =   DuneSimpleBuffsDB.showbuffs
  showdebuffs = DuneSimpleBuffsDB.showdebuffs
  showhaste =   DuneSimpleBuffsDB.showhaste
  testobject =  DuneSimpleBuffsDB.testobject

  initConfig()
  initFrames()
  f:RegisterEvent("PLAYER_TARGET_CHANGED")
  f:RegisterEvent("PLAYER_FOCUS_CHANGED")
  f:RegisterEvent("UNIT_AURA")

  print("Dune Simple Buff v.1.4 loaded");
end

function ConfigPanel_Ok()
  if myCheckButton1:GetChecked() then waagerecht = 1
  else waagerecht = 0
  end

  if myCheckButton3:GetChecked() then showbuffs = 1
  else showbuffs = 0
  end

  if myCheckButton4:GetChecked() then showdebuffs = 1
  else showdebuffs = 0
  end
  
  if HasteButton:GetChecked() then showhaste = 1
  else showhaste = 0
  end

  scale = MySlider:GetValue()
  
  DuneSimpleBuffsDB.waagerecht = waagerecht
  DuneSimpleBuffsDB.showbuffs = showbuffs
  DuneSimpleBuffsDB.showdebuffs = showdebuffs
  DuneSimpleBuffsDB.showhaste = showhaste
  DuneSimpleBuffsDB.scale = MySlider:GetValue()
  updateFrames()
  RefreshBackdrops()
end

function ConfigPanel_Cancel()
  MySlider:SetValue(scale)
  myCheckButton1:SetChecked(waagerecht == 1)
  myCheckButton2:SetChecked(not (waagerecht == 1))
  myCheckButton3:SetChecked(showbuffs == 1)
  myCheckButton4:SetChecked(showdebuffs == 1)
  HasteButton:SetChecked(showhaste == 1)
end

function initConfig()
  configframe.name = "DuneSimpleBuffs"  
  configframe.okay = function (self) ConfigPanel_Ok(); end;
  configframe.cancel = function (self) ConfigPanel_Cancel(); end;
  
  myCheckButton1 = CreateFrame("CheckButton", "myCheckButton_GlobalName1", configframe, "ChatConfigCheckButtonTemplate");
  myCheckButton1:SetPoint("TOPLEFT", 50, -30);
  myCheckButton_GlobalName1Text:SetText("Horizontal");

  myCheckButton2 = CreateFrame("CheckButton", "myCheckButton_GlobalName2", configframe, "ChatConfigCheckButtonTemplate");
  myCheckButton2:SetPoint("TOPLEFT", 200, -30);
  myCheckButton_GlobalName2Text:SetText("Vertical");

  myCheckButton2:SetScript("OnClick", function() myCheckButton1:SetChecked(false) end);  
  myCheckButton1:SetScript("OnClick", function() myCheckButton2:SetChecked(false) end);  

  myCheckButton3 = CreateFrame("CheckButton", "myCheckButton_GlobalName3", configframe, "ChatConfigCheckButtonTemplate");
  myCheckButton3:SetPoint("TOPLEFT", 50, -60);
  myCheckButton_GlobalName3Text:SetText("Show Buffs");
  
  myCheckButton4 = CreateFrame("CheckButton", "myCheckButton_GlobalName4", configframe, "ChatConfigCheckButtonTemplate");
  myCheckButton4:SetPoint("TOPLEFT", 200, -60);
  myCheckButton_GlobalName4Text:SetText("Show Debuffs");

  HasteButton = CreateFrame("CheckButton", "HasteButton_GlobalName", configframe, "ChatConfigCheckButtonTemplate");
  HasteButton:SetPoint("TOPLEFT", 50, -90);
  HasteButton_GlobalNameText:SetText("add Hastebuffs");
  
  MySlider = CreateFrame('Slider', 'MySliderGlobalName', configframe, 'OptionsSliderTemplate')
  MySlider:SetWidth(300)
  MySlider:SetHeight(20)
  MySlider:SetOrientation('HORIZONTAL')
  --MySlider.tooltipText = 'This is the Tooltip hint' 
  getglobal(MySlider:GetName() .. 'Low'):SetText('0.5');
  getglobal(MySlider:GetName() .. 'High'):SetText('5'); 
  getglobal(MySlider:GetName() .. 'Text'):SetText('Scale ' .. string.format("%.2f", scale));
  MySlider:ClearAllPoints()
  MySlider:SetMinMaxValues(0.5, 5)
  MySlider:SetValue(1)  
  MySlider:SetPoint("TOPLEFT", 50, -150);
  MySlider:SetScript("OnValueChanged", 
    function() 
    getglobal(MySlider:GetName() .. 'Text'):SetText('Scale ' .. string.format("%.2f", MySlider:GetValue()))
    end) 
  --MySlider:Show()  

  button = CreateFrame("Button", "DSBButton_GlobalName", configframe, "OptionsButtonTemplate")
  button:SetPoint("TOPLEFT", 50, -200);
  button:SetText("Reset")
  button:SetScript("OnClick", function()
      xpos = 0
      ypos = 0
      scale = 2
      leftanchor = "CENTER"
      current = "NIX"
      waagerecht = 1
      showbuffs = 1
      showdebuffs = 1
	    showhaste = 1
      testobject = "target"
      DuneSimpleBuffsDB.xpos = 0
      DuneSimpleBuffsDB.ypos = 0
      DuneSimpleBuffsDB.scale = 1
      DuneSimpleBuffsDB.leftanchor = "CENTER"
      DuneSimpleBuffsDB.waagerecht = 1
      DuneSimpleBuffsDB.showbuffs = 1
      DuneSimpleBuffsDB.showdebuffs = 1
	  DuneSimpleBuffsDB.showhaste = 1
      DuneSimpleBuffsDB.testobject = "target"
      InterfaceOptionsFrameCancel_OnClick()
      ConfigPanel_Cancel()
      updateFrames()
      RefreshBackdrops()
      print("Frame reset to the center, you can now move it to the desired position.")
    end);
  
  
  ConfigPanel_Cancel()

  InterfaceOptions_AddCategory(configframe);
end  
f:RegisterEvent("VARIABLES_LOADED")
